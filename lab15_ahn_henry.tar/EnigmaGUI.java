import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.concurrent.BlockingQueue;

public class EnigmaGUI {
    public static void main(String args[]){
        new EnigmaFrame();
    }
}
